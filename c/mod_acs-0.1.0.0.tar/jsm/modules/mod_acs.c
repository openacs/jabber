/* ------------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *	
 * 
 *
 *   Copyright Sussdorff & Roy 2001 (www.sussdorff-roy.de)
 *   
 *   Developers: Malte Fliedner  ( maltefliedner@aol.com )
 *               Bjoern Kiesbye  ( xkiesbye@aol.com )       
 * 
 * Acknowledgements
 * 
 * Special thanks to the Jabber Open Source Contributors for their
 * suggestions and support of Jabber, and to Malte Sussdorff for his support
 * and for giving us the posibilety to work on this Project.
 * Thanks to the Programmers of http://jewel.sourceforge.net/ (jewel).
 * 
 * --------------------------------------------------------------------------*/

#include "mod_acs.h"

 



/*
char *COMMUNITY_CLIENT;
char *JABBER_SERVER;
char *ACS_GROUP;
char *STANDARD_BUDDY;
char *PATH_TO_ROSTER_XML;
char *STANDARD_GROUP;
*/ 

    
typedef struct struct_acs_admin_user {
  
  char *COMMUNITY_CLIENT;
  char *JABBER_SERVER; 
  char *ACS_GROUP; 
  char *STANDARD_BUDDY;
  char *PATH_TO_ROSTER_XML;
  char *STANDARD_GROUP;
  struct struct_acs_admin_user *next; 
} *acs_admin_user , _acs_admin_user;
 
acs_admin_user ADMINS;
pool ADMINS_POOL;


void mod_roster_push(udata user, xmlnode item);
xmlnode mod_roster_get(udata user);
xmlnode mod_roster_get_item(xmlnode roster, jid id, int *newflag);


acs_admin_user mod_acs_get_admin(char* jid , acs_admin_user admin_list)
{acs_admin_user cur = NULL;

  for(cur = admin_list; cur != NULL ; cur = cur->next)   
    {if(j_strcmp(jid , cur->COMMUNITY_CLIENT) == 0 ) return cur;}
 
  return NULL;
}
 

 


xmlnode jb_util_acs_x_msg(char* to, char* from, char* jid, char* type, char* agent)
{ xmlnode x,h;
  
 x = xmlnode_new_tag("message");
 xmlnode_put_attrib(x, "to" , to);  
 xmlnode_put_attrib(x, "from" , from);
 xmlnode_insert_tag(x ,"x");
 h = xmlnode_get_tag(x,"x"); 
 xmlnode_put_attrib(h, "xmlns" , "jabber:x:acs");
 xmlnode_insert_tag(h,"jadmin");
 h = xmlnode_get_tag(h,"jadmin");
 xmlnode_put_attrib(h, "type" , type);
 xmlnode_put_attrib(h, "agent" , agent);
 xmlnode_insert_tag(h, "jitem");
 h = xmlnode_get_tag(h,"jitem");
 xmlnode_put_attrib(h , "jid", jid);
 
 return x;

}

acs_x_packet jb_util_acs_x_packet(xmlnode x)
{pool p = pool_new();
 acs_x_packet apacket;
 xmlnode y;
 
 apacket = pmalloc(p,sizeof(_acs_x_packet));
 apacket->p = p;
 apacket->x = x;

 y = xmlnode_get_tag(x, "jadmin");
 
 apacket->type  = xmlnode_get_attrib(y , "type")[0];
 apacket->agent = xmlnode_get_attrib(y , "agent")[0];
 log_warn("localhost" ," JB remove im jb_util %d " , (apacket->first = xmlnode_get_firstchild(y) ));
 apacket->result = NULL;

 return apacket; 
 
} 


mreturn mod_acs_session_in(mapi m, void *arg)
{xmlnode h;
 acs_x_packet apacket;
 acs_x_chain result,send;
 acs_admin_user admin_u = NULL;
 char *COMMUNITY_CLIENT;
 char *JABBER_SERVER;
 char *ACS_GROUP;
 char *STANDARD_BUDDY;
 char *PATH_TO_ROSTER_XML;
 char *STANDARD_GROUP;


  if(m->packet->type != JPACKET_MESSAGE) return M_IGNORE;

  if(!(h = xmlnode_get_tag(m->packet->x , "x")) || !(j_strcmp(xmlnode_get_attrib(h,"xmlns"), "jabber:x:acs" ) == 0) || xmlnode_get_attrib(xmlnode_get_tag(h,"jadmin"),"agent")[0]!= AGENT_IN ) return M_PASS;

if( ( admin_u = mod_acs_get_admin(xmlnode_get_attrib(m->packet->x ,"from" ) , ADMINS ) ) ) {

      COMMUNITY_CLIENT   = admin_u->COMMUNITY_CLIENT;
      JABBER_SERVER      = admin_u->JABBER_SERVER;
      ACS_GROUP          = admin_u->ACS_GROUP;
      STANDARD_BUDDY     = admin_u->STANDARD_BUDDY;
      PATH_TO_ROSTER_XML = admin_u->PATH_TO_ROSTER_XML;
      STANDARD_GROUP     = admin_u->STANDARD_GROUP;
                                                }
  else {
        jutil_error(m->packet->x , TERROR_NOTALLOWED);
        deliver(dpacket_new(m->packet->x) , NULL);
        return M_HANDLED;
       }





  log_warn("localhost" ," Session IN nach dem acs_x checkhallo, xml:\n      %s   "  , xmlnode2str(h)   );
  apacket = jb_util_acs_x_packet(h);
  log_warn("localhost" ," JB remove 0 num wert des types %d  " , apacket->type  );          
  apacket->result = result = pmalloc(apacket->p , sizeof(_acs_x_chain));
  apacket->result->value = NULL; 
  
  switch(apacket->type)
   { 
    case JB_ADDBUDDY:
    {jid id; 
     xmlnode handle,item,roster =  mod_roster_get(m->user);
     int newflag = 0; 
      
      for(apacket->first ; apacket->first != NULL ; apacket->first = xmlnode_get_nextsibling(apacket->first) )
      {   id = jid_new(apacket->p, xmlnode_get_attrib(apacket->first , "jid") );
                
          item  =  mod_roster_get_item(roster, id, &newflag);
          
          if(newflag)
	    {newflag = 0;
             xmlnode_insert_tag(item, "group"); 
             xmlnode_put_attrib(item , "subscription" , "both");
             xmlnode_put_attrib(item ,"name" , xmlnode_get_attrib(apacket->first, "name"));
             handle =  xmlnode_get_tag(item ,  "group");
	     xmlnode_insert_cdata(handle, xmlnode_get_attrib(apacket->first, "group"),-1);  
	     xdb_set(m->si->xc, m->user->id, NS_ROSTER,roster );
             mod_roster_push(m->user,  item);
            }
          else 
	    {  xmlnode_put_attrib(item , "subscription" , "both");
	    if(xmlnode_get_attrib(item , "hidden")) xmlnode_hide_attrib(item , "hidden");
            if(xmlnode_get_attrib(item , "ask")) xmlnode_hide_attrib(item , "ask");
            }
            

      }
      
      apacket->result->value = NULL;
    }
  break;
  
 case JB_REMOVEBUDDY:
    {    
     jid id; 
     xmlnode handle,item,roster =  mod_roster_get(m->user);
     int newflag = 0; 
      
      for(apacket->first ; apacket->first != NULL ; apacket->first = xmlnode_get_nextsibling(apacket->first) )
      {   id = jid_new(apacket->p, xmlnode_get_attrib(apacket->first , "jid") );
                
          item  =  mod_roster_get_item(roster, id, &newflag);
          handle =  xmlnode_dup(item);
          xmlnode_hide(item);
          xmlnode_put_attrib(handle , "subscription" , "none");
         log_warn("localhost" ," Session IN im case in buddyremove handle:\n  %s\ndas item:%s \n das roster: %s  " ,xmlnode2str(handle) , xmlnode2str(item), xmlnode2str(roster) ); 
          xdb_set(m->si->xc, m->user->id, NS_ROSTER,roster );
          mod_roster_push(m->user,  handle);
      }
      
      apacket->result->value = NULL;
    }
 break;
 
 case JB_UNREGISTER:
    { 
      if(j_strcmp(xmlnode_get_attrib(m->packet->x , "from" ) , COMMUNITY_CLIENT ) == 0 )
	{/*the msg gets here only if the user is online, so we destroy his user data first
            to disable the user to relogin*/  
	  
	   
           session s = NULL,cur = NULL;
           xmlnode y;        
     

	  
	   
	    y =  xmlnode_new_tag("password");
            xmlnode_put_attrib(y,"xmlns" , "jabber:iq:auth");
	    xmlnode_put_attrib(y,JB_DELETED,JB_DELETED);
            xdb_set(m->si->xc, m->user->id, NS_AUTH, y );
	    

            y = xmlnode_new_tag("query");
            xmlnode_put_attrib(y,"xmlns" ,"jabber:iq:register");
            xmlnode_put_attrib(y,"xdbns" ,"jabber:iq:register");
	    xmlnode_insert_tag(y,"password");
            xmlnode_insert_tag(y,"username");
            xmlnode_insert_tag(y,"recource");
            xmlnode_free(m->packet->x);
            xdb_set(m->si->xc, m->user->id, NS_AUTH, y );



    

            result->value = NULL;
            
 
            
	     s  = js_session_primary(m->user);
           
	  for(cur = m->user->sessions ; cur != NULL ; cur = cur->next)
	     {js_session_end(cur , "admin removed user");}
          //js_session_end(s , "admin removed user" );   
               //let the primary session end last    
    


     
	 
       }       
      
    }
 break;    
   default: 
     break;
  }

   for(send = apacket->result; send->value != NULL; send = send->next )
     { js_deliver(m->si , jpacket_reset(jpacket_new( send->value ) ) ); }
   
   
    xmlnode_free(m->packet->x);
    pool_free( apacket->p );
           
   return M_HANDLED;

}










mreturn mod_acs_session_out(mapi m, void *arg)
{xmlnode h;
 acs_admin_user admin_u = NULL;
 acs_x_packet apacket;
 acs_x_chain result,send;
 char *COMMUNITY_CLIENT;
 char *JABBER_SERVER;
 char *ACS_GROUP;
 char *STANDARD_BUDDY;
 char *PATH_TO_ROSTER_XML;
 char *STANDARD_GROUP;


  
  if(m->packet->type != JPACKET_MESSAGE) return M_IGNORE;
  
  if(!(h = xmlnode_get_tag(m->packet->x , "x")) || !(j_strcmp(xmlnode_get_attrib(h,"xmlns"), "jabber:x:acs" ) == 0) || ( xmlnode_get_attrib(xmlnode_get_tag(h,"jadmin"),"agent")[0] != AGENT_OUT ) ) return M_PASS;
  log_warn("localhost" ," session out nach dem acs check: %s " ,xmlnode2str(m->packet->x) );

  if( ( admin_u = mod_acs_get_admin(xmlnode_get_attrib(m->packet->x ,"from" ) , ADMINS ) ) ) {

      COMMUNITY_CLIENT   = admin_u->COMMUNITY_CLIENT;
      JABBER_SERVER      = admin_u->JABBER_SERVER;
      ACS_GROUP          = admin_u->ACS_GROUP;
      STANDARD_BUDDY     = admin_u->STANDARD_BUDDY;
      PATH_TO_ROSTER_XML = admin_u->PATH_TO_ROSTER_XML;
      STANDARD_GROUP     = admin_u->STANDARD_GROUP;
                                                }
  else {
        jutil_error(m->packet->x , TERROR_NOTALLOWED);
        deliver(dpacket_new(m->packet->x) , NULL);
        return M_HANDLED;
       }


  apacket = jb_util_acs_x_packet(h);

  apacket->result = result = pmalloc(apacket->p , sizeof(_acs_x_chain));
  apacket->result->value = NULL; 
  
  switch(apacket->type)
   {
    case JB_REMOVEBUDDY: 
    case JB_ADDBUDDY:
      {
       char *sender = xmlnode_get_attrib(apacket->first,"jid"); 
       char *group  = xmlnode_get_attrib(apacket->first,"group");
       char *name   = xmlnode_get_attrib(apacket->first,"name");   
       char *type = ((apacket->type - JB_ADDBUDDY) ?  JB_REMOVEBUDDY_C : JB_ADDBUDDY_C );
       for(apacket->first = xmlnode_get_nextsibling(apacket->first) ; apacket->first != NULL ; apacket->first = xmlnode_get_nextsibling(apacket->first) )
      {   
        result->value = jb_util_acs_x_msg(sender,COMMUNITY_CLIENT ,xmlnode_get_attrib(apacket->first,"jid"),type ,  AGENT_IN_C );

        h = xmlnode_get_tag(xmlnode_get_tag(xmlnode_get_tag(result->value, "x"),"jadmin"),"jitem");
        xmlnode_put_attrib( h ,"name", xmlnode_get_attrib(apacket->first,"name"));
        xmlnode_put_attrib( h ,"group", xmlnode_get_attrib(apacket->first,"group"));    
          log_warn("localhost" ," OUT ADDREMM 1 : %s " ,xmlnode2str(result->value) );       
         result->next = pmalloc(apacket->p, sizeof(_acs_x_chain));
      
        result->next->value = jb_util_acs_x_msg(xmlnode_get_attrib(apacket->first,"jid"),COMMUNITY_CLIENT , sender , type , AGENT_IN_C );
        
        h = xmlnode_get_tag(xmlnode_get_tag(xmlnode_get_tag(result->next->value, "x"),"jadmin"),"jitem");
        xmlnode_put_attrib( h , "name" , name);
        xmlnode_put_attrib( h , "group" , group );  
        log_warn("localhost" ," OUT ADDREMM 2 : %s " ,xmlnode2str(result->next->value) );     
	result = result->next;
        result->next =  pmalloc(apacket->p, sizeof(_acs_x_chain));
        result->next->value = NULL;
        result = result->next;
 
     }
      
      
      
      
    }
  break;
  
  case JB_REGISTER:
    {{xmlnode reg,q, birth,password;
      jid id;
      char *username;
      char *file;
      char *is; 
      pool p2,pj = pool_new();
      spool sp2; 
      
      
      id =jid_new( pj , xmlnode_get_attrib(apacket->first, "jid"));
log_warn("localhost" ,"jid generirung %s  "  , xmlnode2str(apacket->first));
      username = j_strdup(id->user);
     log_warn("localhost" ," reg start :\nusername %s\n jid:  "  , jid_full(id) );
     for( is = username ; *is != '\0' ; ++is)
	{ *is = tolower(*is); } 
 
     //if((reg = js_config(m->si, "register")) == NULL) return M_PASS;

                /* create a new USER.XML */
	       p2 = pool_new();
	       sp2= spool_new(p2);
               spooler(sp2,PATH_TO_ROSTER_XML , username , ".xml" ,sp2);
               birth =  xmlnode_file(spool_print(sp2));
               log_warn("localhost" ," birth%s " ,xmlnode2str(birth) );
               if(birth != NULL  )
                 { 
                   /*The user already exists (username) free all pools and 
                    return a error message to the admin client*/
                   
                   result->value = jb_util_acs_x_msg(COMMUNITY_CLIENT ,COMMUNITY_CLIENT , jid_full(id) , JB_REGISTER_C , AGENT_CLIENT_C );
    
                   xmlnode_put_attrib(xmlnode_get_tag( xmlnode_get_tag(xmlnode_get_tag(result->value , "x"),"jadmin"),"jitem"), "success" , "e");
                   xmlnode_put_attrib( xmlnode_get_tag(xmlnode_get_tag(result->value , "x"),"jadmin"), "id" , xmlnode_get_attrib( xmlnode_get_tag(apacket->x , "jadmin") , "id"));
                   result->next =  pmalloc(apacket->p, sizeof(_acs_x_chain));
                   result->next->value = NULL;
  
                   //log_warn("localhost"," User Exists MSG to client xml:\n %s " ,username );   
  
                   pool_free(p2);
                   //xmlnode_free(m->packet->x);
                   break;                 
 
    } 
		        



  /* user does not exists just free some pools*/
               pool_free(p2);
               xmlnode_free(birth);
                        
               p2 = pool_new();
	       sp2= spool_new(p2);
               spooler(sp2,PATH_TO_ROSTER_XML , "plain.xml" , sp2);
               birth =  xmlnode_file(spool_print(sp2));
               log_warn("localhost" ," loding plain ; %s " ,spool_print(sp2 ));
               log_warn("localhost" ," loding plain ; %s " ,xmlnode2str(birth) );
             //Got the plain XML now insert the new values and save it 
	    // under the new users name
               pool_free(p2); 
	 password = xmlnode_get_tag(birth,"password");
         xmlnode_insert_cdata(password , xmlnode_get_attrib(apacket->first , "pass") , -1);
         password = xmlnode_get_tag(birth , "query");
         password = xmlnode_get_tag(password , "username");
         xmlnode_insert_cdata(password , username , -1 );
         password = xmlnode_get_tag(birth , "query");
         password =  xmlnode_get_tag(password , "password");
         xmlnode_insert_cdata(password , xmlnode_get_attrib(apacket->first , "pass") , -1);
   
         p2 = pool_new();
	 sp2 = spool_new(p2);
         spooler(sp2,PATH_TO_ROSTER_XML , username , ".xml" , sp2 );
         file = spool_print(sp2);     
         xmlnode2file(file,birth );
 
       log_warn("localhost" ," user file created :\nfrom %s\n for: %s " ,m->user->user,username );     
       
        xmlnode_free(birth);
        pool_free(p2);
          
   //inform the Community Client of the succssesfull creation of a new user acount
   
  
result->value = jb_util_acs_x_msg(COMMUNITY_CLIENT ,COMMUNITY_CLIENT , jid_full(id) , JB_REGISTER_C , AGENT_CLIENT_C );
    
                   xmlnode_put_attrib(xmlnode_get_tag( xmlnode_get_tag(xmlnode_get_tag(result->value , "x"),"jadmin"),"jitem"), "success" , "r");
                  
                   xmlnode_put_attrib( xmlnode_get_tag(xmlnode_get_tag(result->value , "x"),"jadmin"), "id" , xmlnode_get_attrib( xmlnode_get_tag(apacket->x , "jadmin") , "id"));  
                   result->next =  pmalloc(apacket->p, sizeof(_acs_x_chain));
                   result->next->value = NULL;
    

  log_warn("bdvlin01.econ.uni-hamburg.de" ," User Created MSG to client xml:\n %s " ,xmlnode2str(result->next->value) );   
       //created a new acount now add the new user to the Community Client
       
  result->next->value = jb_util_acs_x_msg(jid_full(id) , COMMUNITY_CLIENT , COMMUNITY_CLIENT ,JB_ADDBUDDY_C ,AGENT_IN_C );
  q = xmlnode_get_tag( xmlnode_get_tag(xmlnode_get_tag(result->next->value , "x"),"jadmin"),"jitem");
  xmlnode_put_attrib(q , "group" , STANDARD_GROUP );
  xmlnode_put_attrib(q , "name" , STANDARD_BUDDY );
  result = result->next;
  result->next = pmalloc(apacket->p, sizeof(_acs_x_chain));
  result->next->next = pmalloc(apacket->p, sizeof(_acs_x_chain));
  result->next->next->value = NULL;
  result->next->value = jb_util_acs_x_msg( COMMUNITY_CLIENT , COMMUNITY_CLIENT ,jid_full(id) , JB_ADDBUDDY_C ,AGENT_IN_C ); 
 q = xmlnode_get_tag( xmlnode_get_tag(xmlnode_get_tag(result->next->value , "x"),"jadmin"),"jitem");
  xmlnode_put_attrib(q , "group" , STANDARD_GROUP );
  xmlnode_put_attrib(q , "name" , username );


       
   // if there is a Welcome message defined in the config ,send it
          if((reg = js_config(m->si, "welcome")) != NULL)
        {  q = xmlnode_new_tag("message");
	   xmlnode_put_attrib(q, "to", jid_full(id) );
           xmlnode_put_attrib(q, "from", COMMUNITY_CLIENT);
           xmlnode_insert_node(q, xmlnode_get_firstchild(reg));
           result->next->next->value = q;
           result->next->next->next =pmalloc(apacket->p, sizeof(_acs_x_chain));
           result->next->next->next->value = NULL;   
         
        } 
    }}
  break;   
   case JB_UNREGISTER:
     {
      jid id = NULL;
      xmlnode handle;
      int fd;
      spool sp = spool_new(apacket->p); 
      
      id = jid_new(apacket->p , xmlnode_get_attrib( apacket->first , "jid" ));
      result->value =  jb_util_acs_x_msg(jid_full(id) , COMMUNITY_CLIENT , NULL , JB_UNREGISTER_C , AGENT_IN_C );
     
                 result->next = pmalloc(apacket->p , sizeof(_acs_x_chain));
                 result->next->value = NULL;
		 result = result->next;

      result->value =  jb_util_acs_x_msg(COMMUNITY_CLIENT , COMMUNITY_CLIENT , jid_full(id) , JB_UNREGISTER_C , AGENT_CLIENT_C );
          
      handle = xmlnode_get_tag(xmlnode_get_tag(result->value , "x"),"jadmin");
      xmlnode_put_attrib(handle ,"id" , xmlnode_get_attrib(xmlnode_get_tag(xmlnode_get_tag(apacket->x , "x"),"jadmin"),"id"));	  


                 result->next = pmalloc(apacket->p , sizeof(_acs_x_chain));
                 result->next->value = NULL;
        

       spooler(sp , PATH_TO_ROSTER_XML , id->user , ".xml" , sp);
      //fd = remove(spool_print(sp));
      /* don't remove it any more just mark it as deleted in the session in event*/
        /* just remove the user xml-file if the user isn't online */
      

     }            
     break;
   case JB_CHAT:
 {xmlnode b1,b2,grap;
  char* to = NULL;
  char* from = NULL;
  
  to = xmlnode_get_attrib(apacket->first, "jid");
  apacket->first = xmlnode_get_nextsibling(apacket->first);
  from = xmlnode_get_attrib(apacket->first, "jid");
     
  if( to != NULL && from != NULL ){
        b1 = grap = xmlnode_new_tag("message");
        xmlnode_put_attrib(grap, "to", to);
        xmlnode_put_attrib(grap, "from" , from);
        xmlnode_put_attrib(grap, "type" , "chat");
        xmlnode_insert_tag(grap,"body");
        grap = xmlnode_get_tag(grap , "body");
        xmlnode_insert_cdata(grap ,"Hello", -1 );
     
        result->value = b1;
        result->next  = pmalloc(apacket->p , sizeof(_acs_x_chain));
         
      
      b2 = grap = xmlnode_new_tag("message");
      xmlnode_put_attrib(grap, "to", from);
      xmlnode_put_attrib(grap, "from" , to);
      xmlnode_put_attrib(grap, "type" , "chat");
      xmlnode_insert_tag(grap,"body");
      grap = xmlnode_get_tag(grap , "body");
      xmlnode_insert_cdata(grap , "Hello" , -1); 
     
      result->next->value = b2;
      result->next->next =  pmalloc(apacket->p , sizeof(_acs_x_chain));
      result->next->next->value = NULL;
                                 }
                                  else { result->value = NULL; }
     
     
     }    
 break;
  default: 
     break;
  }

   for(send = apacket->result; send->value != NULL; send = send->next )
     { log_warn("acs35.theservice" ," send OUT : %s " ,xmlnode2str(send->value) );     
       js_deliver(m->si , jpacket_reset(jpacket_new( send->value ) ) ); }
   
   
    xmlnode_free(m->packet->x);
    pool_free( apacket->p );
           
   return M_HANDLED;

}










/*
mreturn mod_acs_offline(mapi m,void* arg)
{

 xmlnode h;
 acs_x_packet apacket;
 
  
  if(m->packet->type != JPACKET_MESSAGE) return M_IGNORE;
  
  if(!(h = xmlnode_get_tag(m->packet->x , "x")) || !(j_strcmp(xmlnode_get_attrib(h,"xmlns"), "jabber:x:acs" ) == 0) || ( xmlnode_get_attrib(xmlnode_get_tag(h,"jadmin"),"agent")[0] != AGENT_OUT ) ) return M_PASS;
  log_warn("localhost" ," session out nach dem acs check: %s " ,xmlnode2str(m->packet->x) );
  apacket = jb_util_acs_x_packet(h);

  switch(apacket->type) {

  case JB_UNREGISTER:
    {
      if(j_strcmp(xmlnode_get_attrib(m->packet->x , "from" ) , COMMUNITY_CLIENT ) == 0 )
	{/*the msg gets here only if the user is online, so we destroy his user data first
            to disable the user to relogin/  
	  
	   
	   jid id;
           xmlnode y;        
           int fd;
           pool p= pool_heap(300);
           spool sp = spool_new(p); 
           
           id = jid_new(apacket->p , xmlnode_get_attrib( apacket->first , "jid" ));



               spooler(sp , PATH_TO_ROSTER_XML , id->user , ".xml" , sp);
               fd = remove(spool_print(sp));
  
	       pool_free(p);
               pool_free(apacket->p);	 
      /*
	    y =  xmlnode_new_tag("password");
            xmlnode_put_attrib(y,"xmlns" , "jabber:iq:auth");
	    xmlnode_put_attrib(y,JB_DELETED,JB_DELETED);
            xdb_set(m->si->xc, m->user->id, NS_AUTH, y );
	   

            //if(xdb_act(m->si->xc, m->user->id, NS_AUTH, "insert", NULL, y))
	    //{}   
	    xmlnode_free(y);
            y=xmlnode_new_tag("query");
            xmlnode_put_attrib(y,"xmlns" ,"jabber:iq:register");
            xmlnode_put_attrib(y,"xdbns" ,"jabber:iq:register");
	    xmlnode_insert_tag(y,"password");
            xmlnode_insert_tag(y,"username");
            xmlnode_insert_tag(y,"recource");
            xmlnode_free(m->packet->x);
            xdb_set(m->si->xc, m->user->id, NS_AUTH, y );/
            return M_HANDLED;
        }
    }

  default:
    {break;}

   
   

  }
     
  return M_PASS;

}
*/











mreturn mod_acs_sessions(mapi m ,void *arg)
{  //js_mapi_session(es_IN, m->s, mod_mymod_session, NULL);
  //js_mapi_session(es_OUT, m->s, mod_mymod_session_out, NULL);
   log_warn("localhost","xc->id = %s ",m->si->xc->i->id );
   js_mapi_session(es_IN, m->s, mod_acs_session_in, NULL);
   js_mapi_session(es_OUT, m->s, mod_acs_session_out, NULL);
   return M_PASS;
}


 
 

void mod_acs(jsmi si)
{xmlnode config = NULL , cur = NULL;
 acs_admin_user cur_admin = NULL, last_admin = NULL;
 pool p = pool_new();
 spool sp = spool_new(p);
  
    /* in here we register our callbacks with the "events" we are interested in */
    /* each callback can register an argument (we're passing NULL) that is passed to them again when called */
    /* before looking at specific callbacks above, take a chance now to look at the mod_example_generic one above that explains what they all have in common */

    /* this event is when packets are sent to the server address, to="jabber.org", often used for administrative purposes or special server/resources */
 ADMINS = NULL;
 ADMINS_POOL = pool_new(); 
  
 config = js_config(si,"jadmin");
if(!config){  log_debug("mod_acs","jadmin section in jabber.xml not found !! mod_acs will not be registerd !!");return;}
log_debug("mod_acs , for 0", xmlnode2str(config));
 for(cur = xmlnode_get_tag(config , "admin") ; cur != NULL ; cur = xmlnode_get_nextsibling(xmlnode_get_nextsibling(cur)))
  {
      log_debug("mod_acs "," for 1" );
   cur_admin = pmalloco(ADMINS_POOL , sizeof(_acs_admin_user));
    cur_admin->next = NULL;  
     cur_admin-> JABBER_SERVER =  pstrdup(ADMINS_POOL , xmlnode_get_attrib(cur,"host"));  
      cur_admin-> COMMUNITY_CLIENT = pstrdup(ADMINS_POOL , xmlnode_get_attrib(cur,"community_client"));
       cur_admin->STANDARD_BUDDY = pstrdup(ADMINS_POOL , xmlnode_get_attrib(cur,"standard_buddy"));
        cur_admin->STANDARD_GROUP = pstrdup(ADMINS_POOL , xmlnode_get_attrib(cur , "standard_group"));
      sp = spool_new(p); 
       spooler(sp, "./spool/" , cur_admin->JABBER_SERVER , "/" , sp);
        cur_admin->PATH_TO_ROSTER_XML = pstrdup(ADMINS_POOL , spool_print(sp));
       log_debug("mod_acs" , " for 2 %s" , cur_admin->COMMUNITY_CLIENT);
     if(!cur_admin->JABBER_SERVER){ log_debug("mod_acs","No Jabber server specified !! mod_acs will not be registerd !! for %s", cur_admin->COMMUNITY_CLIENT);break;}
     if(!cur_admin->COMMUNITY_CLIENT){  log_debug("mod_acs","No community_client specified !! mod_acs will not be registerd !! for %s" , cur_admin->COMMUNITY_CLIENT);break;}
     if(!cur_admin->STANDARD_BUDDY){  log_debug("mod_acs","No standard_buddy specified!! mod_acs will not be registerd !! for %s" ,  cur_admin->COMMUNITY_CLIENT);break;}
     if(!cur_admin->STANDARD_GROUP){  log_debug("mod_acs","No standard_group specified!! mod_acs will not be registerd !! for %s" , cur_admin->COMMUNITY_CLIENT);break;}  
    log_debug("mod_acs" , "Admin instance registerd for admin : %s " , cur_admin->COMMUNITY_CLIENT);
        log_debug("mod_acs , for 3" ,xmlnode2str(cur));
    if(ADMINS == NULL ){ADMINS = cur_admin;last_admin = cur_admin;}
    else {last_admin->next = cur_admin; last_admin = cur_admin; }
    log_debug("mod_acs" , "for 4" );
  }

 pool_free(p);
   //js_mapi_register(si,e_REGISTER ,mod_testmod,NULL);

    js_mapi_register(si,e_SESSION ,mod_acs_sessions , NULL);
    //   js_mapi_register(si,e_OFFLINE, mod_acs_offline , NULL);
    }


 
































