

/* ------------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *	
 * 
 *
 *   Copyright Sussdorff & Roy 2001 (www.sussdorff-roy.de)
 *   
 *   Developers: Malte Fliedner  ( maltefliedner@aol.com )
 *               Bjoern Kiesbye  ( xkiesbye@aol.com )       
 * 
 * Acknowledgements
 * 
 * Special thanks to the Jabber Open Source Contributors for their
 * suggestions and support of Jabber, and to Malte Sussdorff for his support
 * and for giving us the posibilety to work on this Project.
 * Thanks to the Programmers of http://jewel.sourceforge.net/ (jewel).
 * 
 * --------------------------------------------------------------------------*/




/*****************************************************************************
 * Adminestrators section , her you can define local settings 
   for your community
 * (instalation). This has to be done before compiling.
 *                                                     
 *  Now what you have to define:                       
 *  In row 61 change the konstants value to  the Name of  
 *  the standart Buddy that will apear in ervery users roster.
 *  examp.:                                                   
 *  change: #define COMMUNITY_CLIENT "ACES@bdvlin01.econ.uni-hamburg.de" 
 *  to:    #define COMMUNITY_CLIENT "YourStandartBuddy@your.jabber.server.com"
 *
 * In row 62 change the konstants value to the URL of your Jabber Server 
 *  examp.:                                                                 
 *  change:   #define JABBER_SERVER    "bdvlin01.econ.uni-hamburg.de"  
 *  to:       #define JABBER_SERVER    "your.jabber.server.com"        
 *                                                                     
 *  ther will be a few more things to be edited  below, how to do that and
 *  what you are doing will be discriped ther.  
 *
 *  Thats it, make sure you spelled everything correctly, 
 *  a change of this settings       
 *  only take effect if a compil. is done after a change.
 ***************************************************************************/


//#define COMMUNITY_CLIENT "aces@localhost"
//#define JABBER_SERVER    "localhost"






/* Server only definitions */

#include "../jsm.h"
       
        
/*#define ACS_GROUP "ACES"  here you can define the name of your community,
                            or some other name if you like  . This is 
                            the group name under wich the buddy's (added throu 
                            your community system) will be displayed, in the                                members jabber client. */ 
 

#define SERVER_URL JABBER_SERVER  /*The  Jabber Server URL*/
/*#define STANDART_BUDDY "aces" The name and the jid of the standart Buddy e.g                                 your community System*/

/*#define PATH_TO_ROSTER_XML "../../spool/bdvlin01.econ.uni-hamburg.de/"
// The Path to your youser directory /path/to/jabber-1.4.1/spool/YourJabberURL/

 * when you reached this Point your are done. 
 * Don 't make any changes from now on.
 * Don 't forget to save your edits. 
 */



#define ROSTER_REMOVE "noe"
#define ROSTER_ADD "jup"
#define REG_USER_EXISTS     "exists"
#define REG_USER_CREATED    "created"
#define JB_CLIENT_REG       "acs_reg_value"
#define JB_CLIENT_CHAT      "acs_start_chat"
#define JB_CLIENT_ADDBUDDY  "acs"
#define JB_CLIENT_REGISTER  "acs_out_register"
#define JB_SERVER_ADDBUDDY  "acs_roster"
#define JB_BUDDY_REMOVE_1o1 "not used yet"  

#define AGENT_IN  49
#define AGENT_OUT 50
#define AGENT_CLIENT 51
#define AGENT_IN_C   "1"
#define AGENT_OUT_C  "2"
#define AGENT_CLIENT_C    "3"
#define JB_ADDBUDDY     97
#define JB_ADDBUDDY_C   "a"  
#define JB_REMOVEBUDDY  98
#define JB_REMOVEBUDDY_C  "b"
#define JB_REGISTER       99
#define JB_REGISTER_C     "c"
#define JB_UNREGISTER         101
#define JB_UNREGISTER_C       "e"
#define JB_CHAT         100
#define JB_CHAT_C       "d"

#define JB_DELETED "deleted"

typedef struct struct_acs_x_message_chain
{
  xmlnode value; /* the xmlpacket to hold*/
  struct struct_acs_x_message_chain *next;
} *acs_x_chain, _acs_x_chain;


typedef struct struct_acs_x_packet
{
  pool p;
  unsigned int type; /*type of x*/
  unsigned int agent; /*  agent to be delivered to */
  xmlnode x;   /* x - data starts here */
  xmlnode first;
  struct struct_acs_x_message_chain *result;
} *acs_x_packet, _acs_x_packet;

typedef struct struct_acs_x_sleeper_chain
{ pool p;
  char* arg;
  struct struct_acs_x_sleeper_chain *next;
} *acs_x_sleeper_chain , _acs_x_sleeper_chain;   

typedef struct struct_acs_x_sleeper 
{ pool p;
  struct struct_acs_x_sleeper_chain *value;
  short int todo;
} *acs_x_sleeper , _acs_x_sleeper;








