/* ------------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *	
 * 
 *
 *   Copyright Sussdorff & Roy 2001 (www.sussdorff-roy.de)
 *   
 *   Developers: Malte Fliedner  ( maltefliedner@aol.com )
 *               Bjoern Kiesbye  ( xkiesbye@aol.com )       
 * 
 * Acknowledgements
 * 
 * Special thanks to the Jabber Open Source contributors for their
 * suggestions and support of Jabber and to Malte Sussdorff for his support
 * and for giving us the possibility to work on this Project.
 * 
 * --------------------------------------------------------------------------*/

/* Installation edits start a bit further down *******************************/




/*#ifndef __LIB_JABBER__*/
#define __LIB_JABBER__

#include "jabber.h"
//#include "ns.h"
//#include "nsthread.h"


#define ROSTER_REMOVE "noe"
#define ROSTER_ADD    "jup"
#define REG_USER_EXISTS     "exists"
#define REG_USER_CREATED    "created"
#define JB_CLIENT_REG       "acs_reg_value"
/********************************************************************/
// Here you have to edit some things

//#define COMMUNITY_CLIENT "aces@localhost/ACES"
//                        YourStandardBuddy@your.jabber.server.com/ACES"
// this will be the name of your standard Buddy the one you have registered
// at the beginning, don't change any thing behind the '/' it has to be '/ACES'


//#define JABBER_SERVER    "localhost"
//                        "your.jabber.server.com"
// URL of your jabber server don't forget the ' " ' signs at the beginning 
// and at the and

//#define CLIENT_PASS_JB  "acesrules"
//                      "Password"
// The password of your stdandard Buddy to login the Jabber Server.

//#define VIRTUAL_SERVER_NAME "Server1"
// Change to                "The Name of Your virtual AOLServer"
// e.g. this is the V. AOLServer that loads the jabber client modules.



// Now You are done. Don't make any changes from now on.
// Don't forget to save your edits. 
/*********************************************************************/
#define DEFAULT_PORT 5222

#define LINE_LENGTH 513

enum
{
	JABBER_ONLINE,
	JABBER_AWAY,
	JABBER_DND,
	JABBER_XA,
	JABBER_CHAT,
	JABBER_OFFLINE,
};



#define	DB_JABBER "j"
#define	DB_AIM "a"
#define	DB_YAHOO "y"
#define	DB_MSN "m"
#define	DB_ICQ "i"
#define	DB_IRC "r"
#define	DB_CONFERENCE "c"


#define JB_JABBER 1
#define JB_AIM 2
#define JB_ICQ 3
#define JB_MSN 4
#define JB_YAHOO 5
#define JB_IRC 6
#define JB_CONFERENCE 7



#define AIM_ONLINE  "Connected"
#define AIM_OFFLINE "?"
#define YAHOO_ONLINE "Online"
#define YAHOO_OFFLINE "?"
#define MSN_ONLINE "Connected"
#define MSN_OFFLINE "?"
#define ICQ_ONLINE "Connected"
#define ICQ_OFFLINE "?"
#define IRC_ONLINE "?"
#define IRC_OFFLINE "?"
#define CONFERENCE_ONLINE "?"
#define CONFERENCE_OFFLINE "?"


#define CONFERENCE_ROOM_ACTIVE 1
#define CONFERENCE_ERROR -1
#define CONFERENCE_OK 0
#define CONFERENCE_THREAD_ID "threadid"
#define CONFERENCE_THREAD_ID_LEN 8
#define JB_SPELL_ERROR -10
/* 
** The following structure holds the connection information.
** I included the cookie and the common name, because both those things 
** come from the server.  Common name might be moved out later.
**                           - shane
*/

typedef struct JABBERCONN {
    char   passwd[LINE_LENGTH+1];
    char   *jid;	/* The jabber id, of the form user@host/resource */
    int	   listenerID;
    jconn  conn;		/* The actual jabber connection struct */
    int    id;			/*  for secure auth, encryption value */
    int    reg_flag;		/* Don't know what this does either */
    Ns_Thread *threadr;         /* ptr to the thread that reads from the conn*/ 
    Ns_Mutex loginlock;
    Ns_Event *loginevent;
} JABBER_Conn; 
 
typedef struct struct_jabber_buddy
{       char *name;				/* Users name */
	char *jid;				/* the buddy's id */
	char *sub;				/* Subscriptions state */
        int  status;                             /* Their current status */
        char *resrc;                            /* User's resource */ 
        char *service;                           /* User's service */
        pool p;
  //JABBER_Conn *JConn;
} _jabber_buddy , *jabber_buddy;




typedef struct struct_Jb_Conf_User {
  char* nick;
  char* prity_nick;
  char* remote_id;
  pool p;
  char* user_id;
  char* status;
  struct struct_Jb_Conf_User* next;
} *Jb_Conf_User, _Jb_Conf_User;


typedef struct struct_Jb_Conf_Room {
  char * RoomName;
  char* RoomID;
  char* ThreadID;
  char* subject;
  xmlnode real_room_jids;
  Jb_Conf_User RoomMembers;
  Ns_RWLock* lock;
  pool p;
  struct struct_Jb_Conf_Room* next;
} *Jb_Conf_Room , _Jb_Conf_Room;





typedef struct PipePool_struct
{
  pool p;
  char* sql_first;
  long int len;
  long int cur_len; 

} *Jb_PipePool , _Jb_PipePool;

typedef struct DbPipe_struct
{
  long int thread_end;
  long int poolsize;
  time_t interval; 
  time_t nextpush;
  Ns_Mutex* lock;
  Ns_Event* send_event;
  xmlnode pool;
  xmlnode send_pool;
  char* envelop_name;
  
  
} *Jb_DbPipe , _Jb_DbPipe;



/*
** Name:    JABBER_Login
** Purpose: This function encapsulates the login process to JABBER
** Input:   handle   - user's handle
**          passwd   - user's password
**          host     - notification server to use
**          port     - port number of notifcation server
** Output:  0 on success, -1 on failure
*/

JABBER_Conn *JABBER_Login(char *handle, char *passwd, char *host, int port);

/*
** Name:    JABBER_SendMessage
** Purpose: This function encapuslates the sending of an instant message
** Input:   handle - user's handle who is receiving the message
**          message - the actual message to send
** Output:  0 on success, -1 on failure
*/

int JABBER_SendMessage(JABBER_Conn *JConn, char *handle, char *message);


/*
** Name:    JABBER_Logout
** Purpose: This function properly logs out of the JABBER service
** Input:   none
** Output:  0 on success, -1 on failure
*/

int JABBER_Logout(JABBER_Conn *JConn);

/*
** Name:    JABBER_ChangeState
** Purpose: This function changes the current state of the user
** Input:   state - integer representation of the state
** Output:  0 on success, -1 on failure
*/

int JABBER_ChangeState(JABBER_Conn *JConn, int state);






void JABBERCleanUp();

void JABBER_Chat(JABBER_Conn* ,char**);

void JABBER_AddBuddy(JABBER_Conn*, char** , int);

void JABBER_RemoveBuddy(JABBER_Conn*, char** , int );

char* JABBER_Register(JABBER_Conn*,  char**);

void JABBER_Unregister(JABBER_Conn*,  char**);

void JABBERRegUpdate(JABBER_Conn* );

void JABBERRegValidation(char* , char*);

void JABBER_AddRemBuddy(JABBER_Conn*, char** , int , char* );

void NS_MutexLock(Ns_Mutex*);

void NS_MutexUnlock(Ns_Mutex*);

int Jb_Send_Wait_For_Response(jconn  , int  , xmlnode  , void** ,char* );

char* JABBER_AddTransportBuddy(JABBER_Conn* , jid  , const char* );

char* JABBER_RemoveTransportBuddy(JABBER_Conn* , jid );

int JABBER_Dbml(char*  );

int JABBER_Dbml_Direckt(char*  );

int JABBER_0or1true(char* );

void Jb_PresenceUnOrSubscribed(jconn  ,jid );

void JABBER_AfterLogin(JABBER_Conn* );

int JCgetConnState();

int Jb_LoginMain();

void Jb_Startup(void*);

int Jb_TransportOnline(char* );

void Jb_Sleep(int );

int JABBER_Dbml_Main(char* );

int Jb_DbPipeSend(Jb_DbPipe  , int );

int Jb_DbPipePoolAdd(Jb_DbPipe ,  char*);

void Jb_ConferencePresence(jpacket);

void Jb_ConferenceMessages(jpacket );

int Jb_CreateConferenceRoom(char* , char* , char*  , char*  , char* , jconn , char* );

Ns_Set* Jb_ActiveConferenceRooms(Jb_Conf_Room , Tcl_Interp*);

Ns_Set* Jb_ActiveRoomMembers(char*  , Jb_Conf_Room  , Tcl_Interp*);

int Jb_SendConferenceInvite(char*  , char*  , char*  , char*  , int  , jconn   );

char *Jb_ConfGetNextThreadID(pool );

char *Jb_ConfGetNextRoomID(pool );

void Jb_ConferenceInit();

void Jb_InsertNewRoom(Jb_Conf_Room new , Jb_Conf_Room rooms , int );

void Jb_DelConferenceRoom(Jb_Conf_Room ,jid , jconn );

int Jb_SendConferenceSubject(char*  , char*  , char*  , jconn , char* );

void Jb_ConferenceIq(jpacket );

void Jb_ReciveInviteV1(void* );

int JABBER_Subscription_Check(char* );

void Jb_DbPipeStartupInit(long int  , time_t  );

void Jb_DbPipeLoginInit(Jb_DbPipe);

void Jb_DbPipeLogoutCleanUp(Jb_DbPipe );

int Jb_DbPipeSend(Jb_DbPipe  , int  );

int Jb_DbPipePoolAdd(Jb_DbPipe ,  char* );

long int Jb_StackRemain(int address);

/*#endif*/ /* __LIB_JABBER__ */

#define AGENT_IN          49
#define AGENT_OUT         50
#define AGENT_CLIENT      51
#define AGENT_IN_C        "1"
#define AGENT_OUT_C       "2"
#define AGENT_CLIENT_C    "3"
#define JB_ADDBUDDY       97
#define JB_ADDBUDDY_C     "a"  
#define JB_REMOVEBUDDY    98
#define JB_REMOVEBUDDY_C  "b"
#define JB_REGISTER       99
#define JB_REGISTER_C     "c"
#define JB_UNREGISTER       101
#define JB_UNREGISTER_C     "e"
#define JB_CHAT           100
#define JB_CHAT_C         "d" 

typedef struct struct_acs_x_message_chain
{
  xmlnode value; /* the xmlpacket to hold*/
  struct struct_acs_x_message_chain *next;
} *acs_x_chain, _acs_x_chain;


typedef struct struct_acs_x_packet
{
  pool p;
  unsigned int type; /*type of x*/
  unsigned int agent; /*  agent to be delivered to */
  xmlnode x;   /* x - data starts here */
  xmlnode first;
  struct struct_acs_x_message_chain *result;
} *acs_x_packet, _acs_x_packet;


int charcheck(char* strg);
/*{char *str;
        check for low and invalid ascii characters in the username 
    if(strg != NULL)
        for(str = strg; *str != '\0'; str++)
            if(*str <= 32 || *str == ':' || *str == '@' || *str == '<' || *str == '>' || *str == '\'' || *str == '"' || *str == '&') return 1;

    return 0;
}*/

typedef struct tcllist2chararray {
  pool p;
  int len;
  char * * item;
} *charlist , _charlist;

charlist jb_listtochar(char* , pool );




typedef struct jb_object_ring_item {
  char* cid;
  int *id;
  xmlnode object;
  Ns_Event *notifie;
  struct jb_object_ring_item *next;
  struct jb_object_ring_item *back;
} *Jb_Ring_Item , _Jb_Ring_Item;

typedef struct jb_object_ring {
  pool p;
  Ns_Mutex lock;
  struct jb_object_ring_item *first;
  struct jb_object_ring_item *last;
} *Jb_Ring, _Jb_Ring;


Jb_Ring Jb_Ring_Init(void);

Jb_Ring_Item Jb_Ring_GetRemItem(int *id , Jb_Ring ring);

void  Jb_Ring_InsertItem(Jb_Ring ring , Jb_Ring_Item item);

Jb_Ring_Item Jb_Ring_GetRemItem_cid(char* , Jb_Ring );































